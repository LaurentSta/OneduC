<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('category_name'); // ✅ Correction : underscore au lieu du tiret
            $table->text('category_description')->nullable(); // ✅ Ta nouvelle colonne description
            $table->string('category_slug'); // ✅ Correction : underscore au lieu du tiret
            $table->string('category_image')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};
