<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('contacts', function (Blueprint $table) {
            $table->id();
            $table->string('prenom')->nullable();
            $table->string('nom');
            $table->string('email');
            $table->string('phone')->nullable();
            $table->string('heure_appel')->nullable();
            $table->enum('type_utilisateur', ['formateur', 'stagiaire']); // 💡 Meilleure clarté
            $table->json('objet')->nullable(); // ✅ OK pour les objets multiples (formateur)
            $table->text('message');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contacts');
    }
};
